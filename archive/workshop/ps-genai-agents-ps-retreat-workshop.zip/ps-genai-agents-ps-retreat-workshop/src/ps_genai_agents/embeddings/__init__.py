"""This module contains all the embedding files."""
