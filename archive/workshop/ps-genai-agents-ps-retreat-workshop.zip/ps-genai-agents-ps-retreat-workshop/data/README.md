This directory contains all data that the agents may interact with.
